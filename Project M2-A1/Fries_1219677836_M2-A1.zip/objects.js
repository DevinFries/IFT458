var students = ['John', 'Sammy', 'Jaime', 'Mike', 'Jane'];

//console.log(students[0]);
//console.log(students[2]);

//console.log(students.length);

var grades = [90,99,89,100,80];

//console.log(grades[0]);
//console.log(grades[2]);

//console.log(grades.length);

//console.log(grades[grades.length - 1]);
//console.log(grades[grades.length - 2]);

var studentInfo = [
                    {
                        'name':'John',
                        'grade':90
                    },
                    {
                        'name':'Sammy',
                        'grade':99
                    },
                    {
                        'name':'Jaime',
                        'grade':89
                    },
                    {
                        'name':'Mike',
                        'grade':100
                    },
                    {
                        'name':'Jane',
                        'grade':80
                    },
                ];

                
